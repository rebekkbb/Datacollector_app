//
//  QuestionnaireViewController.swift
//  polarBleSdkTestApp
//
//  Created by Rebekka Brøyn on 08/09/2020.
//  Copyright © 2020 Polar. All rights reserved.
//

import UIKit
import SwiftyDropbox

class QuestionnaireViewController: UIViewController {
    
    var folderName=""
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    @IBOutlet weak var happyBefore: UISlider!
    @IBOutlet weak var sadBefore: UISlider!
    @IBOutlet weak var calmBefore: UISlider!
    @IBOutlet weak var stressed: UISlider!
    
    @IBOutlet weak var happyAfter: UISlider!
    @IBOutlet weak var sadAfter: UISlider!
    @IBOutlet weak var calmAfter: UISlider!
    @IBOutlet weak var afraid: UISlider!
    
    @IBOutlet weak var sendButton: UIButton!
    
    
    @IBAction func send(_ sender: Any) {
        FileHandling.writeTofile(filename: "questions.txt", text: "Happy,Sad,calm,stressed/afraid \n Before: \(happyBefore.value),\(sadBefore.value),\(calmBefore.value),\(stressed.value) \n After: \(happyAfter.value),\(sadAfter.value),\(calmAfter.value),\(afraid.value)", add: false)
        FileHandling.read(fileName: "questions.txt")
        uploadToDropbox(fileName: "values.txt")
        uploadToDropbox(fileName: "questions.txt")
        uploadToDropbox(fileName: "GSRvalues.txt")
        sendButton.isEnabled=false
    }
    func uploadToDropbox(fileName: String){
        let filePath = try!FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false).appendingPathComponent(fileName)
        let client = DropboxClientsManager.authorizedClient
        
        _ = client?.files.upload(path: "/data\(folderName)/\(fileName)", autorename:true, input: filePath)
        .response { response, error in
            if let response = response {
                print(response)
            } else if let error = error {
                print(error)
            }
        }
        .progress { progressData in
            print(progressData)
        }
        
    }

}
