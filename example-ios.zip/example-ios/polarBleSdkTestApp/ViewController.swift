import UIKit
import PolarBleSdk
import RxSwift
import CoreBluetooth
import SwiftyDropbox


class ViewController: UIViewController,
    CBCentralManagerDelegate, CBPeripheralDelegate,
                      PolarBleApiObserver,
                      PolarBleApiPowerStateObserver,
                      PolarBleApiDeviceHrObserver,
                      PolarBleApiDeviceInfoObserver,
                      PolarBleApiDeviceFeaturesObserver,
                      PolarBleApiLogger,
PolarBleApiCCCWriteObserver{
    
   
    // NOTICE this example utilizes all available features
    var api = PolarBleApiDefaultImpl.polarImplementation(DispatchQueue.main, features: Features.allFeatures.rawValue)
    var centralManager: CBCentralManager!
    var GSR: CBPeripheral?
    var broadcast: Disposable?
    var ecgToggle: Disposable?
    var accToggle: Disposable?
    var ppgToggle: Disposable?
    var ppiToggle: Disposable?
    var searchToggle: Disposable?
    var autoConnect: Disposable?
    var entry: PolarExerciseEntry?
    var deviceId = "75157825" // TODO replace this with your device id
    var clipNum = ""
    
    let serviceUUID = CBUUID(string: "FFE0")
    let GSRcharacteristicUUID = CBUUID(string: "FFE1")
    
    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        if central.state == .poweredOn{
            centralManager.scanForPeripherals(withServices: [serviceUUID], options: nil)
        }
    }
    
    func centralManager(_ central: CBCentralManager, didDiscover peripheral: CBPeripheral, advertisementData: [String: Any], rssi RSSI:NSNumber) {
        centralManager.stopScan()
        GSR = peripheral
        centralManager.connect(peripheral, options: nil)
    }
    
    func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) {
        peripheral.delegate = self
        peripheral.discoverServices([serviceUUID])
    }
    
    func peripheral(_ peripheral: CBPeripheral, didDiscoverServices error: Error?) {
        if let service = peripheral.services?.first(where: {$0.uuid == serviceUUID}){
            peripheral.discoverCharacteristics([GSRcharacteristicUUID],for: service)
        }
    }
    func peripheral(_ peripheral: CBPeripheral, didDiscoverCharacteristicsFor service: CBService, error: Error?) {
        if let characteristic = service.characteristics?.first(where: {$0.uuid == GSRcharacteristicUUID}){
            peripheral.setNotifyValue(true, for: characteristic)
        }
    }
    func peripheral(_ peripheral: CBPeripheral, didUpdateValueFor characteristic: CBCharacteristic,error: Error?){
        if let data = characteristic.value{
            FileHandling.writeTofile(filename: "GSRvalues.txt", text: "\n\(String(Int(NSDate().timeIntervalSince1970))),\(String(bytes: data, encoding: .utf8)!)", add:true)
        }
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        connect.isEnabled = false
        disconnect.isEnabled = false
        upload.isEnabled = false
        api.observer = self
        api.deviceHrObserver = self
        api.deviceInfoObserver = self
        api.powerStateObserver = self
        api.deviceFeaturesObserver = self
        api.logger = self
        api.cccWriteObserver = self
        clipNumber.delegate=self
        api.polarFilter(false)
        NSLog("\(PolarBleApiDefaultImpl.versionInfo())")
        FileHandling.removeFromDirectory(fileName: "values.txt")
        FileHandling.removeFromDirectory(fileName: "GSRvalues.txt")
        myButtonInControllerPressed()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        clipNumber.resignFirstResponder()
        if !disconnect.isEnabled && !upload.isEnabled && !(clipNumber.text!.isEmpty) {
            connect.isEnabled = true
        }
    }

    @IBOutlet weak var upload: UIButton!
    @IBOutlet weak var disconnect: UIButton!
    @IBOutlet weak var connect: UIButton!
    @IBOutlet weak var clipNumber: UITextField!
    
    @IBAction func connectToDevice(_ sender: Any) {
        centralManager = CBCentralManager()
        centralManager.delegate = self
        FileHandling.writeTofile(filename: "GSRvalues.txt", text: "Time,GSR", add:true)
        do{
            try api.connectToDevice(deviceId)
            FileHandling.writeTofile(filename: "values.txt", text:"Time,HR,RR", add:true)
            connect.isEnabled = false
            disconnect.isEnabled = true
        } catch let err {
            print("\(err)")
        }
    }
    
    @IBAction func disconnectFromDevice(_ sender: Any) {
        centralManager.cancelPeripheralConnection(GSR!)
        do{
            try api.disconnectFromDevice(deviceId)
            disconnect.isEnabled = false
            upload.isEnabled = true
        } catch let err {
            print("\(err)")
        }
    }
    
    
    @IBAction func ecgToggle(_ sender: Any) {
        if ecgToggle == nil {
            ecgToggle = api.requestEcgSettings(deviceId).asObservable().flatMap({ (settings) -> Observable<PolarEcgData> in
                return self.api.startEcgStreaming(self.deviceId, settings: settings.maxSettings())
            }).observeOn(MainScheduler.instance).subscribe{ e in
                switch e {
                case .next(let data):
                    for µv in data.samples {
                        NSLog("    µV: \(µv)")
                    }
                case .error(let err):
                    NSLog("start ecg error: \(err)")
                    self.ecgToggle = nil
                case .completed:
                    break
                }
            }
        } else {
            ecgToggle?.dispose()
            ecgToggle = nil
        }
    }
    
    
    @IBAction func ppgToggle(_ sender: Any) {
        if ppgToggle == nil {
            ppgToggle = api.requestPpgSettings(deviceId).asObservable().flatMap({ (settings) -> Observable<PolarPpgData> in
                return self.api.startOhrPPGStreaming(self.deviceId, settings: settings.maxSettings())
            }).observeOn(MainScheduler.instance).subscribe{ e in
                switch e {
                case .completed:
                    NSLog("ppg finished")
                case .error(let err):
                    NSLog("start ppg error: \(err)")
                    self.ppgToggle = nil
                case .next(let data):
                    for item in data.samples {
                        NSLog("    ppg0: \(item.ppg0) ppg1: \(item.ppg1) ppg2: \(item.ppg2)")
                    }
                }
            }
        } else {
            ppgToggle?.dispose()
            ppgToggle = nil
        }
    }
    
    
    @IBAction func searchToggle(_ sender: Any) {
        if searchToggle == nil {
            searchToggle = api.searchForDevice().observeOn(MainScheduler.instance).subscribe{ e in
                switch e {
                case .completed:
                    NSLog("search complete")
                case .error(let err):
                    NSLog("search error: \(err)")
                case .next(let item):
                    NSLog("polar device found: \(item.name) connectable: \(item.connectable) address: \(item.address.uuidString)")
                }
            }
        } else {
            searchToggle?.dispose()
            searchToggle = nil
        }
    }
    
    @IBAction func uploadToDropbox(_ sender: Any) {
        clipNum = clipNumber.text!
        performSegue(withIdentifier: "questions", sender: self)

    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var vc = segue.destination as! QuestionnaireViewController
        vc.folderName = self.clipNum
    }
    
    // PolarBleApiObserver
    func deviceConnecting(_ polarDeviceInfo: PolarDeviceInfo) {
        NSLog("DEVICE CONNECTING: \(polarDeviceInfo)")
    }
    
    func deviceConnected(_ polarDeviceInfo: PolarDeviceInfo) {
        NSLog("DEVICE CONNECTED: \(polarDeviceInfo)")
        deviceId = polarDeviceInfo.deviceId
    }
    
    func deviceDisconnected(_ polarDeviceInfo: PolarDeviceInfo) {
        NSLog("DISCONNECTED: \(polarDeviceInfo)")
    }
    
    // PolarBleApiDeviceInfoObserver
    func batteryLevelReceived(_ identifier: String, batteryLevel: UInt) {
        NSLog("battery level updated: \(batteryLevel)")
    }
    
    func disInformationReceived(_ identifier: String, uuid: CBUUID, value: String) {
        NSLog("dis info: \(uuid.uuidString) value: \(value)")
    }
    
    // PolarBleApiDeviceHrObserver
    func hrValueReceived(_ identifier: String, data: PolarHrData) {
        FileHandling.writeTofile(filename: "values.txt",text: "\n\(String(Int(NSDate().timeIntervalSince1970))),\(String(data.hr))",add: true)
        if data.rrs.count != 0{
            FileHandling.writeTofile(filename: "values.txt", text:",\(String(data.rrs[0]))", add: true)
        }
        else {
            FileHandling.writeTofile(filename: "values.txt", text:"nil", add: true)
        }
        //NSLog("HR notification: \(data.hr) rrs: \(data.rrs) rrsMs: \(data.rrsMs) c: \(data.contact) s: \(data.contactSupported)")
    }
    
    func hrFeatureReady(_ identifier: String) {
        NSLog("HR READY")
    }
    
    // PolarBleApiDeviceEcgObserver
    func ecgFeatureReady(_ identifier: String) {
        NSLog("ECG READY \(identifier)")
    }
    
    // PolarBleApiDeviceAccelerometerObserver
    func accFeatureReady(_ identifier: String) {
        NSLog("ACC READY")
    }
    
    func ohrPPGFeatureReady(_ identifier: String) {
        NSLog("OHR PPG ready")
    }
    
    // PolarBleApiPowerStateObserver
    func blePowerOn() {
        NSLog("BLE ON")
    }
    
    func blePowerOff() {
        NSLog("BLE OFF")
    }
    
    // PPI
    func ohrPPIFeatureReady(_ identifier: String) {
        NSLog("PPI Feature ready")
    }

    func ftpFeatureReady(_ identifier: String) {
        NSLog("FTP ready")
    }
    
    func message(_ str: String) {
        NSLog(str)
    }
    
    /// ccc write observer
    func cccWrite(_ address: UUID, characteristic: CBUUID) {
        NSLog("ccc write: \(address) chr: \(characteristic)")
    }
    
    func myButtonInControllerPressed() {
        // Legacy authorization flow that grants a long-lived token.
        DropboxClientsManager.authorizeFromController(UIApplication.shared,
                                                      controller: self,
                                                      openURL: { (url: URL) -> Void in
                                                        UIApplication.shared.open(url)
                                                      })

      // New: OAuth 2 code flow with PKCE that grants a short-lived token with scopes.
      /*let scopeRequest = ScopeRequest(scopeType: .user, scopes: ["account_info.read","files/upload"], includeGrantedScopes: false)
      DropboxClientsManager.authorizeFromControllerV2(
          UIApplication.shared,
          controller: self,
          loadingStatusDelegate: nil,
          openURL: { (url: URL) -> Void in UIApplication.shared.openURL(url) },
          scopeRequest: scopeRequest
      )*/
    }
    
    
}
extension ViewController : UITextFieldDelegate{
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
    }
}
