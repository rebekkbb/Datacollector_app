//
//  FileHandling.swift
//  polarBleSdkTestApp
//
//  Created by Rebekka Brøyn on 08/09/2020.
//  Copyright © 2020 Polar. All rights reserved.
//

import Foundation
import UIKit

class FileHandling{
    static func writeTofile(filename: String, text: String, add: Bool){
        let fileURL = try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false)
            .appendingPathComponent(filename)

        if let outputStream = OutputStream(url: fileURL, append: add) {
            outputStream.open()
            let bytesWritten = outputStream.write(text, maxLength: String(text).count);
            if bytesWritten < 0 { print("write failure") }
            outputStream.close()
        } else {
            print("Unable to open file")
        }
        print(fileURL)
    }
    static func read(fileName: String) {
        let filePath = try!FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false)
        .appendingPathComponent(fileName)
        
        do {
            let savedString = try String(contentsOf: filePath)
            print("\(savedString)")
        } catch {
            print("Error reading saved file")
        }
    }

    static func removeFromDirectory(fileName: String) {
        let fileManager = FileManager.default
        let myDocuments = fileManager.urls(for: .documentDirectory, in: .userDomainMask).first!
        do {
            try fileManager.removeItem(at: myDocuments)
        } catch {
            return
        }

    }
}
    

